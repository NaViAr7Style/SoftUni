async function getInfo() {
    const BASE_URL = "http://localhost:3030/jsonstore/bus/businfo/";
    const busStop = document.getElementById("stopId").value;
    const stopNameDiv = document.getElementById("stopName");
    const ulContainer = document.getElementById("buses");
    
    ulContainer.replaceChildren();
    stopNameDiv.textContent = "";

    try {
        let busStopRes = await fetch(`${BASE_URL}${busStop}`);
        let data = await busStopRes.json();

        stopNameDiv.textContent = data.name;

        for (const [key, value] of Object.entries(data.buses)) {
            const li = document.createElement("li");
            li.textContent = `Bus ${key} arrives in ${value} minutes`;
            ulContainer.appendChild(li);
        }

    } catch(e) {
        stopNameDiv.textContent = "Error";
    }
}