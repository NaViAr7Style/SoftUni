package christmasPastryShop.repositories.interfaces;

import christmasPastryShop.entities.booths.interfaces.Booth;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class BoothRepositoryImpl implements BoothRepository<Booth> {

    private Map<Integer, Booth> models;

    public BoothRepositoryImpl() {
        models = new LinkedHashMap<>();
    }

    @Override
    public Booth getByNumber(int number) {
        return models.get(number);
    }

    @Override
    public Collection<Booth> getAll() {
        return models.values().stream().collect(Collectors.toUnmodifiableList());
    }

    @Override
    public void add(Booth booth) {
        models.put(booth.getBoothNumber(), booth);
    }

}
