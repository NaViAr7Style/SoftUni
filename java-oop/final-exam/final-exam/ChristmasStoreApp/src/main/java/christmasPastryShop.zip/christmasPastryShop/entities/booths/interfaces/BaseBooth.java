package christmasPastryShop.entities.booths.interfaces;

import christmasPastryShop.entities.cocktails.interfaces.Cocktail;
import christmasPastryShop.entities.delicacies.interfaces.Delicacy;

import java.util.LinkedHashMap;
import java.util.Map;

import static christmasPastryShop.common.ExceptionMessages.INVALID_NUMBER_OF_PEOPLE;
import static christmasPastryShop.common.ExceptionMessages.INVALID_TABLE_CAPACITY;

public abstract class BaseBooth implements Booth {

    private Map<String, Delicacy> delicacyOrders;
    private Map<String, Cocktail> cocktailOrders;
    private int boothNumber;
    private int capacity;
    private int numberOfPeople;
    private double pricePerPerson;
    private boolean isReserved;
    private double price;

    protected BaseBooth(int boothNumber, int capacity, double pricePerPerson) {
        delicacyOrders = new LinkedHashMap<>();
        cocktailOrders = new LinkedHashMap<>();
        setBoothNumber(boothNumber);
        setCapacity(capacity);
        setPricePerPerson(pricePerPerson);
    }

    @Override
    public int getBoothNumber() {
        return boothNumber;
    }

    @Override
    public int getCapacity() {
        return capacity;
    }

    @Override
    public boolean isReserved() {
        return isReserved;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void reserve(int numberOfPeople) {
        setNumberOfPeople(numberOfPeople);
        price = numberOfPeople * pricePerPerson;
        isReserved = true;
    }

    @Override
    public double getBill() {

        double totalDelicaciesCost = delicacyOrders.values().stream()
                .mapToDouble(Delicacy::getPrice)
                .sum();

        double totalCocktailsCost = cocktailOrders.values().stream()
                .mapToDouble(Cocktail::getPrice)
                .sum();

        return totalDelicaciesCost + totalCocktailsCost + price;
    }

    @Override
    public void clear() {
        delicacyOrders.clear();
        cocktailOrders.clear();
        numberOfPeople = 0;
        isReserved = false;
        price = 0;
    }

    private void setBoothNumber(int boothNumber) {
        this.boothNumber = boothNumber;
    }

    private void setCapacity(int capacity) {

        if (capacity < 0) {
            throw new IllegalArgumentException(INVALID_TABLE_CAPACITY);
        }

        this.capacity = capacity;
    }

    private void setNumberOfPeople(int numberOfPeople) {

        if (numberOfPeople <= 0 || capacity < numberOfPeople) {
            throw new IllegalArgumentException(INVALID_NUMBER_OF_PEOPLE);
        }

        this.numberOfPeople = numberOfPeople;
    }

    private void setPricePerPerson(double pricePerPerson) {
        this.pricePerPerson = pricePerPerson;
    }

}
