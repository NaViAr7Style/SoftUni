package christmasPastryShop.repositories.interfaces;

import christmasPastryShop.entities.cocktails.interfaces.Cocktail;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class CocktailRepositoryImpl implements CocktailRepository<Cocktail> {

    private Map<String, Cocktail> models;

    public CocktailRepositoryImpl() {
        models = new LinkedHashMap<>();
    }

    @Override
    public Cocktail getByName(String name) {
        return models.get(name);
    }

    @Override
    public Collection<Cocktail> getAll() {
        return models.values().stream().collect(Collectors.toUnmodifiableList());
    }

    @Override
    public void add(Cocktail cocktail) {
        models.put(cocktail.getName(), cocktail);
    }

}
