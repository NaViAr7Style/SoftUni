package bg.softuni.productshop.domain.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {

//    @Bean
//    public ModelMapper createModelMapper() {
//        return new ModelMapper();
//    }
//
//    @Bean
//    public Scanner createScanner() {
//        return new Scanner(System.in);
//    }
//
//    @Bean
//    public Gson createGson() {
//        return new GsonBuilder()
//                .setPrettyPrinting()
//                .excludeFieldsWithoutExposeAnnotation()
//                .create();
//    }

}
