package bg.softuni.bookshopsystem.entities.enums;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
