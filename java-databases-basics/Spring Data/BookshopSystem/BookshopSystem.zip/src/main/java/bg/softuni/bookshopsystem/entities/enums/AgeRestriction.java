package bg.softuni.bookshopsystem.entities.enums;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
